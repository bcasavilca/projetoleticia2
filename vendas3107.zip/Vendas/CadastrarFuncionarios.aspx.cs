﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Vendas
{
    public partial class CadastrarFuncionarios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            tboxCpfFuncionario.Text = "";
            tboxCpfFuncionario.Focus();
            tboxNmCliente.Enabled = false;
            tboxNmRua.Enabled = false;
            tboxCidCliente.Enabled = false;
            tboxCepCliente.Enabled = false;
            tboxNumCasa.Enabled = false;
            tboxTelCliente.Enabled = false;
            ddlUf.Enabled = false;
            btnInserir.Enabled = false;
            btnLimpar.Enabled = false;
            gvFuncionarios.Enabled = false;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("TelaMenu.aspx");
        }

        protected void tbnInserir_Click(object sender, EventArgs e)
        {

        }

        protected void btnLimpar_Click(object sender, EventArgs e)
        {

        }

        protected void tboxCpf_TextChanged(object sender, EventArgs e)
        {
           
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            ValidaCpf(tboxCpfFuncionario.Text);

            tboxCpfFuncionario.Text = "";
            tboxCpfFuncionario.Focus();
            tboxNmCliente.Enabled = true;
            tboxNmRua.Enabled = true;
            tboxCidCliente.Enabled = true;
            tboxCepCliente.Enabled = true;
            tboxNumCasa.Enabled = true;
            tboxTelCliente.Enabled = true;
            ddlUf.Enabled = true;
            btnInserir.Enabled = true;
            btnLimpar.Enabled = true;
            gvFuncionarios.Enabled = true;
        }

        public static bool ValidaCpf(string cpf)
        {
            int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            string tempCpf;
            string digito;

            int soma;
            int resto;

            cpf = cpf.Trim();
            cpf = cpf.Replace(".", "").Replace("-", "");

            if (cpf.Length != 11)
            {
                return false;
            }
            tempCpf = cpf.Substring(0, 9);

            soma = 0;

            for (int i = 0; i < 9; i++)
            {
                soma += int.Parse(tempCpf[i].ToString()) * (multiplicador1[i]);
            }
            resto = soma % 11;

            if (resto < 2)
            {
                resto = 0;
            }
            else
            {
                resto = 11 - resto;
            }

            digito = resto.ToString();
            tempCpf = tempCpf + digito;
            int soma2 = 0;

            for (int i = 0; i < 10; i++)
            {
                soma2 += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];
            }

            resto = soma2 % 11;

            if (resto < 2)
            {
                resto = 0;
            }
            else
            {
                resto = 11 - resto;
            }

            digito = digito + resto.ToString();
            return cpf.EndsWith(digito);
           
        }
    
    }
}