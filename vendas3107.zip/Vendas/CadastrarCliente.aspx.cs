﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Vendas
{
    public partial class CadastrarCliente : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            tboxCpf.Text = "";
            tboxCpf.Focus();
            tboxNmUsuario.Enabled = false;
            tboxNmCliente.Enabled = false;
            tboxNmRua.Enabled = false;
            tboxCidCliente.Enabled = false;
            tboxCepCliente.Enabled = false;
            tboxNmSenha.Enabled = false;
            tboxTelCliente.Enabled = false;
            tboxNumCasa.Enabled = false;
            btnInserir.Enabled = false;
            btnLimpar.Enabled = false;
            gvCliente.Enabled = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("TelaMenu.aspx");
        }
        // clicar nos botoes para criar os eventos onclick
        protected void tbnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();


                //*BD_VendasConnectionString = copia lá do web.config

                con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BDProjetoFinalConnectionString"].ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Select * from cliente";
                cmd.Connection = con;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "cliente");
                //começa fazer as inserções
                //new SqlCommandBuilder(traz do "da")
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataRow drow = ds.Tables["cliente"].NewRow();
                drow["nome"] = tboxNmCliente.Text;
                drow["cpf"] = tboxCpf.Text;
                drow["rua"] = tboxNmRua.Text;
                drow["numero"] = tboxNumCasa.Text;
                drow["cidade"] = tboxCidCliente.Text;
                drow["uf"] = ddlUf.Text;
                drow["cep"] = tboxCepCliente.Text;
                drow["telefone"] = tboxTelCliente.Text;
                drow["usuario"] = tboxNmUsuario.Text;
                drow["senha"] = tboxNmSenha.Text;


               
                ds.Tables["cliente"].Rows.Add(drow);
                da.Update(ds, "cliente");
            }
            catch (Exception erro)
            {
                Response.Write("Erro! - " + erro.Message);
            }
        }

        protected void btnLimpar_Click(object sender, EventArgs e)
        {

        }

        protected void tboxCpf_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button6_Click(object sender, EventArgs e)
        {

        }

        protected void tboxTelCliente_TextChanged(object sender, EventArgs e)
        {

        }
    }
}