﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Vendas
{
    public partial class CadastrarMarca : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            tboxMarca.Focus();
            gvMarca.DataSource = null; //vai fazer o carregamento com o grid da marca
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("TelaMenu.aspx");
        }

        protected void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();


                //*BD_VendasConnectionString = copia lá do web.config

                con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BDProjetoFinalConnectionString"].ConnectionString;
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Select * from marca";
                cmd.Connection = con;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "marca");
                //começa fazer as inserções
                //new SqlCommandBuilder(traz do "da")
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataRow drow = ds.Tables["marca"].NewRow();

                drow["nome"] = tboxMarca.Text;
         
                
                ds.Tables["marca"].Rows.Add(drow);
                da.Update(ds, "marca");
            }
            catch (Exception erro)
            {
                Response.Write("Erro! - " + erro.Message);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            tboxMarca.Text = "";
            tboxMarca.Focus();
        }
    }
}